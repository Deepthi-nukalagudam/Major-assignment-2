# Major-Assignment-2 (Week 7) - Deepthi Nukalagudam

This repository contains the submitted materials for Week 7 Major Assignment 2.
It includes sample code (HTML/CSS/JS), mock geo data and CSV so the maps render locally, example screenshots, and the Word report.

## Files and Structure
```
Major-Assignment-2/
├── index.html
├── style.css
├── script.js
├── data/
│   ├── ma_counties.geojson   <- mock GeoJSON (used by script)
│   └── ma_data.csv           <- mock population & gini CSV
├── images/
│   ├── zoom_output.png
│   └── marching_output.png
└── Week7_MajorAssignment2_Deepthi_Nukalagudam_fullcode.docx
```

## How to run locally
1. Clone or download the repository.
2. Serve the folder with a local HTTP server (recommended):
   - Python 3: `python -m http.server 8000`
   - Then open: `http://localhost:8000/`
3. The `index.html` will load the mock GeoJSON and CSV and render three choropleth-style maps (mock data).

## GitHub Pages
To publish on GitHub Pages:
1. Push the repository to GitHub (e.g. `yourusername/Major-Assignment-2`).
2. Go to **Settings → Pages**, set source to `main` branch and root `/` folder.
3. After a minute, your site will be available at `https://yourusername.github.io/Major-Assignment-2/`

## Notes
- The data folder contains mock data so the example runs out of the box. Replace `data/ma_counties.geojson` and `data/ma_data.csv` with your real TopoJSON/CSV files as needed.
- The script (`script.js`) can read TopoJSON as well if provided; it detects both GeoJSON and TopoJSON.
