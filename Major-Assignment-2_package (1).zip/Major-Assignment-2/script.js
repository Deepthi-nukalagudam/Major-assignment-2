// script.js - loads geojson (or topojson) and CSV, draws 3 maps
const topoPath = 'data/ma_counties.geojson'; // using GeoJSON for mock data
const csvPath = 'data/ma_data.csv';

const svgA = d3.select('#mapA');
const svgB = d3.select('#mapB');
const svgC = d3.select('#mapC');

const width = +svgA.attr('width');
const height = +svgA.attr('height');

const tooltip = d3.select('#tooltip');

function padFips(x){
  if (x == null) return null;
  const s = String(x);
  return s.length < 5 ? s.padStart(5,'0') : s;
}

Promise.all([
  d3.json(topoPath),
  d3.csv(csvPath, d => {
    d.fips = padFips(d.fips || d.FIPS || d.GEOID);
    d.county = d.county || d.County || d.NAME;
    d.pop1980 = +(d.pop1980 || d.POP1980 || d.POP_1980 || 0);
    d.pop2010 = +(d.pop2010 || d.POP2010 || d.POP_2010 || 0);
    d.gini = {};
    ['1980','1990','2000','2010','2019'].forEach(y => {
      const key = 'gini_' + y;
      if (d[key] !== undefined) d.gini[y] = +d[key];
      else if (d['gini' + y] !== undefined) d.gini[y] = +d['gini' + y];
    });
    return d;
  })
]).then(([geojson, rows]) => {
  // If this file is TopoJSON, convert to GeoJSON
  let geo = geojson;
  if (geojson.type === 'Topology') {
    const key = Object.keys(geojson.objects)[0];
    geo = topojson.feature(geojson, geojson.objects[key]);
  }

  geo.features.forEach(f => {
    if (!f.id) {
      const p = f.properties;
      f.id = padFips(p.FIPS || p.GEOID || p.COUNTYFP || p.id);
    } else {
      f.id = padFips(f.id);
    }
  });

  const dataByFips = new Map(rows.map(r => [r.fips, r]));
  geo.features.forEach(f => { f.properties.data = dataByFips.get(f.id) || {}; });

  const projection = d3.geoMercator().fitSize([width, height], geo);
  const path = d3.geoPath().projection(projection);

  const pop1980Values = geo.features.map(f => f.properties.data.pop1980 || 0);
  const popChangeVals = geo.features.map(f => (f.properties.data.pop2010 || 0) - (f.properties.data.pop1980 || 0));
  const gini2019Vals = geo.features.map(f => {
    const g = f.properties.data.gini && f.properties.data.gini['2019'];
    return (g == null ? NaN : g);
  }).filter(v=>!isNaN(v));

  const popA = d3.scaleSequential(d3.interpolateViridis).domain(d3.extent(pop1980Values));
  const changeScale = d3.scaleDiverging().domain([d3.min(popChangeVals), 0, d3.max(popChangeVals)]).interpolator(d3.interpolateRdBu);
  const giniScale = d3.scaleSequential(d3.interpolateViridis).domain(d3.extent(gini2019Vals.length ? gini2019Vals : [0.25,0.5]));

  function drawMap(svg, colorFunc, prefix) {
    const g = svg.append('g').attr('class', 'counties');
    g.selectAll('path')
      .data(geo.features)
      .join('path')
      .attr('d', path)
      .attr('id', d => `${prefix}-${d.id}`)
      .attr('fill', d => {
        const c = colorFunc(d);
        return (c == null || isNaN(c)) ? '#eee' : c;
      })
      .attr('stroke','#666').attr('stroke-width',0.6)
      .on('mouseenter', function(event, d){
        d3.selectAll('#mapA path, #mapB path').classed('fade', p => p.id !== d.id);
        d3.selectAll(`#mapA-${d.id}, #mapB-${d.id}, #mapC-${d.id}`).classed('county-highlight', true);
      })
      .on('mouseleave', function(event, d){
        d3.selectAll('#mapA path, #mapB path').classed('fade', false);
        d3.selectAll(`#mapA-${d.id}, #mapB-${d.id}, #mapC-${d.id}`).classed('county-highlight', false);
      });
  }

  drawMap(svgA, d => {
    const p = d.properties.data.pop1980;
    return (p==null ? null : popA(p));
  }, 'mapA');

  drawMap(svgB, d => {
    const delta = (d.properties.data.pop2010 || 0) - (d.properties.data.pop1980 || 0);
    return (isNaN(delta) ? null : changeScale(delta));
  }, 'mapB');

  drawMap(svgC, d => {
    const g = d.properties.data.gini && d.properties.data.gini['2019'];
    return (g==null ? null : giniScale(g));
  }, 'mapC');

  // simple legends
  createLegend('#legendA','Population 1980', popA, d3.extent(pop1980Values));
  createDivergingLegend('#legendB','Population change (2010 - 1980)', changeScale, [d3.min(popChangeVals), d3.max(popChangeVals)]);
  createLegend('#legendC','Gini 2019', giniScale, d3.extent(gini2019Vals.length?gini2019Vals:[0.25,0.5]));

  // tooltip for mapC
  d3.selectAll('#mapC path').on('mouseenter', function(event, d){
    showTooltip(event, d);
  }).on('mouseleave', hideTooltip);

  function showTooltip(event, feature){
    const data = feature.properties.data || {};
    const times = ['1980','1990','2000','2010','2019'].map(y => ({year:+y, value: data.gini && data.gini[y] ? +data.gini[y] : null})).filter(x=>x.value!==null);
    tooltip.style('display','block').style('left',(event.pageX+12)+'px').style('top',(event.pageY+12)+'px');
    tooltip.html('');
    tooltip.append('div').style('font-weight','700').text(data.county || feature.properties.NAME || feature.id);
    if (data.pop1980) tooltip.append('div').text(`Pop 1980: ${data.pop1980.toLocaleString()}`);
    if (data.pop2010) tooltip.append('div').text(`Pop 2010: ${data.pop2010.toLocaleString()}`);
    if (data.gini && data.gini['2019']!==undefined) tooltip.append('div').text(`Gini 2019: ${(+data.gini['2019']).toFixed(3)}`);
    if (times.length){
      const w=220,h=80,m={t:6,r:6,b:18,l:36};
      const svg = tooltip.append('svg').attr('width',w).attr('height',h);
      const x = d3.scaleLinear().domain(d3.extent(times,d=>d.year)).range([m.l,w-m.r]);
      const y = d3.scaleLinear().domain(d3.extent(times,d=>d.value)).nice().range([h-m.b,m.t]);
      const line = d3.line().x(d=>x(d.year)).y(d=>y(d.value)).curve(d3.curveMonotoneX);
      svg.append('path').datum(times).attr('d',line).attr('fill','none').attr('stroke','#111').attr('stroke-width',1.2);
      const xAxis = d3.axisBottom(x).ticks(times.length).tickFormat(d3.format('d'));
      const yAxis = d3.axisLeft(y).ticks(3);
      svg.append('g').attr('transform',`translate(0,${h-m.b})`).call(xAxis).attr('font-size',10);
      svg.append('g').attr('transform',`translate(${m.l},0)`).call(yAxis).attr('font-size',10);
    }
  }

  function hideTooltip(){ tooltip.style('display','none'); }

  function createLegend(selector, title, scale, extent){
    const container = d3.select(selector);
    container.html('');
    container.append('div').style('font-size','12px').style('font-weight','600').text(title);
    const w=200,h=10;
    const canvas = container.append('svg').attr('width', w).attr('height', 30);
    const defs = canvas.append('defs');
    const gradId = `grad-${selector.replace('#','')}`;
    const grad = defs.append('linearGradient').attr('id', gradId).attr('x1','0%').attr('x2','100%');
    const n = 8;
    const domain = d3.range(n).map(i => i/(n-1));
    domain.forEach((t,i) => {
      grad.append('stop').attr('offset',`${(i/(n-1)*100)}%`).attr('stop-color', scale(extent[0] + t*(extent[1]-extent[0])));
    });
    canvas.append('rect').attr('x',0).attr('y',6).attr('width',w).attr('height',h).attr('fill',`url(#${gradId})`).attr('rx',3);
    const lab = container.append('div').style('display','flex').style('justify-content','space-between').style('width',(w)+'px');
    lab.append('span').text(d3.format(',')(Math.round(extent[0])));
    lab.append('span').text(d3.format(',')(Math.round(extent[1])));
  }

  function createDivergingLegend(selector, title, scale, extent){
    const container = d3.select(selector);
    container.html('');
    container.append('div').style('font-size','12px').style('font-weight','600').text(title);
    const w=200,h=10;
    const canvas = container.append('svg').attr('width', w).attr('height', 30);
    const defs = canvas.append('defs');
    const gradId = `grad-${selector.replace('#','')}`;
    const grad = defs.append('linearGradient').attr('id', gradId).attr('x1','0%').attr('x2','100%');
    const stops = [
      {offset:0, color: scale(extent[0])},
      {offset:50, color: scale(0)},
      {offset:100, color: scale(extent[1])}
    ];
    stops.forEach(s => grad.append('stop').attr('offset', `${s.offset}%`).attr('stop-color', s.color));
    canvas.append('rect').attr('x',0).attr('y',6).attr('width',w).attr('height',h).attr('fill',`url(#${gradId})`).attr('rx',3);
    const lab = container.append('div').style('display','flex').style('justify-content','space-between').style('width',(w)+'px');
    lab.append('span').text(d3.format(',')(Math.round(extent[0])));
    lab.append('span').text('0');
    lab.append('span').text(d3.format(',')(Math.round(extent[1])));
  }

}).catch(err => { console.error('Error loading data', err); });
